export default function LoginPage() {
  return (
    <main dir="rtl" style={{
      minHeight: "100vh",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      padding: "20px"
    }}>
      <section style={{
        background: "white",
        padding: "28px",
        borderRadius: "18px",
        width: "100%",
        maxWidth: "420px",
        boxShadow: "0 4px 20px #0001"
      }}>
        <h1 style={{ textAlign: "center", color: "#065f46" }}>
          مرحباً بك في Khedma 🇩🇿
        </h1>

        <p style={{ textAlign: "center", color: "#64748b" }}>
          سجّل الدخول إلى حسابك
        </p>

        <form>
          <label>البريد الإلكتروني</label>
          <input
            type="email"
            placeholder="example@email.com"
            required
            style={inputStyle}
          />

          <label>كلمة المرور</label>
          <input
            type="password"
            placeholder="أدخل كلمة المرور"
            required
            style={inputStyle}
          />

          <button type="submit" style={buttonStyle}>
            تسجيل الدخول
          </button>
        </form>

        <p style={{ textAlign: "center" }}>
          ليس لديك حساب؟ <a href="/register" style={{ color: "#059669" }}>
            إنشاء حساب
          </a>
        </p>
      </section>
    </main>
  );
}

const inputStyle = {
  width: "100%",
  padding: "13px",
  margin: "10px 0 20px",
  border: "1px solid #cbd5e1",
  borderRadius: "9px",
  fontSize: "16px"
};

const buttonStyle = {
  width: "100%",
  padding: "14px",
  background: "#059669",
  color: "white",
  border: "none",
  borderRadius: "9px",
  fontSize: "17px"
};