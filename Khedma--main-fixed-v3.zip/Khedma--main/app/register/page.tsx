"use client";

import { useState } from "react";

export default function RegisterPage() {
  const [role, setRole] = useState("worker");

  return (
    <main dir="rtl" style={{
      minHeight: "100vh",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      padding: "20px"
    }}>
      <section style={{
        background: "white",
        padding: "28px",
        borderRadius: "18px",
        width: "100%",
        maxWidth: "440px",
        boxShadow: "0 4px 20px #0001"
      }}>
        <h1 style={{ textAlign: "center", color: "#065f46" }}>
          إنشاء حساب جديد 🇩🇿
        </h1>

        <p>اختر نوع الحساب:</p>

        <div style={{ display: "flex", gap: "10px" }}>
          <button type="button" onClick={() => setRole("worker")}
            style={role === "worker" ? activeStyle : normalStyle}>
            عامل
          </button>

          <button type="button" onClick={() => setRole("employer")}
            style={role === "employer" ? activeStyle : normalStyle}>
            صاحب عمل
          </button>
        </div>

        <form style={{ marginTop: "22px" }}>
          <label>الاسم الكامل</label>
          <input required placeholder="أدخل اسمك" style={inputStyle} />

          <label>رقم الهاتف</label>
          <input required type="tel" placeholder="05 أو 06 أو 07" style={inputStyle} />

          <label>البريد الإلكتروني</label>
          <input required type="email" placeholder="example@email.com" style={inputStyle} />

          <label>كلمة المرور</label>
          <input required type="password" placeholder="أنشئ كلمة مرور" style={inputStyle} />

          <button type="submit" style={submitStyle}>
            إنشاء الحساب
          </button>
        </form>

        <p style={{ textAlign: "center" }}>
          لديك حساب؟ <a href="/login" style={{ color: "#059669" }}>تسجيل الدخول</a>
        </p>
      </section>
    </main>
  );
}

const inputStyle = {
  width: "100%",
  padding: "13px",
  margin: "9px 0 18px",
  border: "1px solid #cbd5e1",
  borderRadius: "9px",
  fontSize: "16px"
};

const normalStyle = {
  flex: 1,
  padding: "13px",
  border: "1px solid #cbd5e1",
  borderRadius: "9px",
  background: "white"
};

const activeStyle = {
  ...normalStyle,
  background: "#d1fae5",
  border: "2px solid #059669",
  color: "#065f46"
};

const submitStyle = {
  width: "100%",
  padding: "14px",
  background: "#059669",
  color: "white",
  border: "none",
  borderRadius: "9px",
  fontSize: "17px"
};