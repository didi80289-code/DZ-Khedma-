"use client";

import { useState } from "react";

type Job = {
  id: number;
  title: string;
  category: string;
  location: string;
  salary: string;
  employer: string;
  description: string;
};

const initialJobs: Job[] = [
  {
    id: 1,
    title: "عامل بناء",
    category: "البناء",
    location: "تبسة",
    salary: "3000 دج / يوم",
    employer: "مؤسسة البناء",
    description: "نبحث عن عامل بناء لديه خبرة."
  },
  {
    id: 2,
    title: "عامل في محل تجاري",
    category: "التجارة",
    location: "تبسة",
    salary: "2500 دج / يوم",
    employer: "محل تجاري",
    description: "المساعدة في ترتيب السلع وخدمة الزبائن."
  },
  {
    id: 3,
    title: "عامل فلاحي",
    category: "الفلاحة",
    location: "العوينات",
    salary: "2000 دج / يوم",
    employer: "مزرعة محلية",
    description: "العمل في جمع المحاصيل الزراعية."
  },
  {
    id: 4,
    title: "عامل تنظيف",
    category: "التنظيف",
    location: "بئر العاتر",
    salary: "1800 دج / يوم",
    employer: "شركة خدمات",
    description: "تنظيف المحلات والمكاتب."
  }
];

const categories = [
  "الكل",
  "البناء",
  "النقل",
  "التنظيف",
  "الصيانة",
  "الفلاحة",
  "المطاعم",
  "التجارة",
  "الحراسة",
  "أخرى"
];

export default function Home() {
  const [page, setPage] = useState("home");
  const [role, setRole] = useState("worker");
  const [jobs, setJobs] = useState<Job[]>(initialJobs);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("الكل");
  const [applications, setApplications] = useState<number[]>([]);
  const [favorites, setFavorites] = useState<number[]>([]);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [user, setUser] = useState("");
  const [logged, setLogged] = useState(false);
  const [title, setTitle] = useState("");
  const [location, setLocation] = useState("تبسة");
  const [salary, setSalary] = useState("");
  const [description, setDescription] = useState("");
  const [notice, setNotice] = useState("");

  const filteredJobs = jobs.filter(job =>
    (category === "الكل" || job.category === category) &&
    (job.title + job.location + job.category)
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  function notify(message: string) {
    setNotice(message);
    setTimeout(() => setNotice(""), 3000);
  }

  function addJob() {
    if (!title.trim() || !salary.trim() || !description.trim()) {
      notify("يرجى ملء جميع المعلومات");
      return;
    }

    const newJob: Job = {
      id: Date.now(),
      title,
      category: category === "الكل" ? "أخرى" : category,
      location,
      salary,
      employer: user || "صاحب عمل",
      description
    };

    setJobs([newJob, ...jobs]);
    setTitle("");
    setSalary("");
    setDescription("");
    setPage("jobs");
    notify("تم نشر عرض العمل بنجاح");
  }

  function apply(id: number) {
    if (!logged) {
      setPage("login");
      notify("سجل الدخول أولاً للتقديم");
      return;
    }

    if (applications.includes(id)) {
      notify("لقد قدمت طلباً لهذا العمل");
      return;
    }

    setApplications([...applications, id]);
    notify("تم إرسال طلبك بنجاح");
  }

  function toggleFavorite(id: number) {
    setFavorites(old =>
      old.includes(id)
        ? old.filter(x => x !== id)
        : [...old, id]
    );
  }

  const card = {
    background: "white",
    borderRadius: 16,
    padding: 18,
    boxShadow: "0 3px 15px #0000000a",
    border: "1px solid #e8eee9",
    marginBottom: 14
  } as const;

  const button = {
    background: "#087c50",
    color: "white",
    border: "none",
    borderRadius: 10,
    padding: "12px 16px",
    fontWeight: "bold",
    cursor: "pointer"
  } as const;

  const field = {
    width: "100%",
    padding: 13,
    borderRadius: 10,
    border: "1px solid #d5ded8",
    marginTop: 7,
    marginBottom: 15,
    fontSize: 15,
    background: "white"
  } as const;
  function JobCard({ job }: { job: Job }) {
    return (
      <div style={card}>
        <div style={{
          display: "flex",
          justifyContent: "space-between",
          gap: 8
        }}>
          <div>
            <span style={{
              color: "#087c50",
              fontSize: 12,
              fontWeight: "bold"
            }}>
              {job.category}
            </span>
            <h3 style={{ margin: "8px 0" }}>{job.title}</h3>
          </div>

          <button
            onClick={() => toggleFavorite(job.id)}
            style={{
              border: 0,
              background: "transparent",
              fontSize: 23
            }}
          >
            {favorites.includes(job.id) ? "❤️" : "♡"}
          </button>
        </div>

        <p>📍 {job.location}</p>
        <p style={{ color: "#087c50", fontWeight: "bold" }}>
          💰 {job.salary}
        </p>
        <p style={{ color: "#64748b", fontSize: 13 }}>
          صاحب العمل: {job.employer}
        </p>
        <p>{job.description}</p>

        <div style={{ display: "flex", gap: 8 }}>
          <button
            style={{ ...button, flex: 1 }}
            onClick={() => setSelectedJob(job)}
          >
            التفاصيل
          </button>

          <button
            style={{
              ...button,
              flex: 1,
              background: "#e9f5ee",
              color: "#087c50"
            }}
            onClick={() => apply(job.id)}
          >
            {applications.includes(job.id) ? "تم التقديم" : "تقديم"}
          </button>
        </div>
      </div>
    );
  }

  return (
    <main
      dir="rtl"
      style={{
        minHeight: "100vh",
        background: "#f3f7f4",
        color: "#18352a",
        fontFamily: "Arial, sans-serif",
        paddingBottom: 85
      }}
    >
      <header style={{
        background: "#075c3d",
        color: "white",
        padding: "22px 18px",
        borderRadius: "0 0 22px 22px"
      }}>
        <div style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center"
        }}>
          <div>
            <h1 style={{ margin: 0, fontSize: 27 }}>
              Khedma 🇩🇿
            </h1>
            <p style={{ margin: "7px 0 0", color: "#c9ead9" }}>
              فرصتك للعمل تبدأ من هنا
            </p>
          </div>

          <button
            onClick={() => setPage(logged ? "profile" : "login")}
            style={{
              background: "white",
              color: "#075c3d",
              border: 0,
              padding: 11,
              borderRadius: 10
            }}
          >
            {logged ? "حسابي" : "دخول"}
          </button>
        </div>
      </header>

      <div style={{
        maxWidth: 700,
        margin: "auto",
        padding: 16
      }}>
        {notice && (
          <div style={{
            ...card,
            background: "#e0f5e8",
            color: "#075c3d"
          }}>
            {notice}
          </div>
        )}

        {page === "home" && (
          <>
            <section style={{
              ...card,
              background: "#e2f4e9",
              marginTop: 8
            }}>
              <h2>ابحث عن عمل بالقرب منك</h2>
              <p>اكتشف فرص العمل اليومية والمؤقتة في ولايتك.</p>
              <button
                style={button}
                onClick={() => setPage("jobs")}
              >
                استكشف الوظائف ←
              </button>
            </section>

            <h2>مجالات العمل</h2>

            <div style={{
              display: "grid",
              gridTemplateColumns: "repeat(2,1fr)",
              gap: 10
            }}>
              {categories.slice(1).map((cat, i) => (
                <button
                  key={cat}
                  onClick={() => {
                    setCategory(cat);
                    setPage("jobs");
                  }}
                  style={{
                    ...card,
                    margin: 0,
                    textAlign: "right",
                    fontWeight: "bold",
                    color: "#075c3d"
                  }}
                >
                  {["🏗️","🚚","🧹","🔧","🌾","🍽️","🛒","🛡️","💼"][i]} {cat}
                </button>
              ))}
            </div>

            <h2 style={{ marginTop: 25 }}>أحدث عروض العمل</h2>

            {jobs.slice(0, 3).map(job => (
              <JobCard key={job.id} job={job} />
            ))}
          </>
        )}

        {page === "jobs" && (
          <>
            <h2>البحث عن الوظائف</h2>

            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="ابحث عن وظيفة أو بلدية..."
              style={field}
            />

            <select
              value={category}
              onChange={e => setCategory(e.target.value)}
              style={field}
            >
              {categories.map(c => (
                <option key={c}>{c}</option>
              ))}
            </select>

            <p>{filteredJobs.length} عروض متاحة</p>

            {filteredJobs.length ? (
              filteredJobs.map(job => (
                <JobCard key={job.id} job={job} />
              ))
            ) : (
              <div style={card}>
                لا توجد عروض مطابقة للبحث حالياً.
              </div>
            )}
          </>
        )}

        {page === "post" && (
          <>
            <h2>نشر عرض عمل جديد</h2>

            <div style={card}>
              <label>عنوان الوظيفة</label>
              <input
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="مثلاً: عامل بناء"
                style={field}
              />

              <label>مجال العمل</label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value)}
                style={field}
              >
                {categories.slice(1).map(c => (
                  <option key={c}>{c}</option>
                ))}
              </select>

              <label>مكان العمل</label>
              <input
                value={location}
                onChange={e => setLocation(e.target.value)}
                placeholder="البلدية والولاية"
                style={field}
              />

              <label>الأجر</label>
              <input
                value={salary}
                onChange={e => setSalary(e.target.value)}
                placeholder="مثلاً: 3000 دج / يوم"
                style={field}
              />

              <label>تفاصيل العمل</label>
              <textarea
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="اشرح طبيعة العمل والشروط..."
                style={{ ...field, minHeight: 110 }}
              />

              <button
                onClick={addJob}
                style={{ ...button, width: "100%" }}
              >
                نشر العرض
              </button>
            </div>
          </>
        )}
        {page === "favorites" && (
          <>
            <h2>وظائفي المفضلة ❤️</h2>
            {jobs.filter(j => favorites.includes(j.id)).map(job => (
              <JobCard key={job.id} job={job} />
            ))}
            {favorites.length === 0 && (
              <div style={card}>لم تضف أي وظيفة إلى المفضلة بعد.</div>
            )}
          </>
        )}

        {page === "applications" && (
          <>
            <h2>طلباتي</h2>
            {jobs.filter(j => applications.includes(j.id)).map(job => (
              <JobCard key={job.id} job={job} />
            ))}
            {applications.length === 0 && (
              <div style={card}>لم تقدم على أي وظيفة بعد.</div>
            )}
          </>
        )}

        {page === "login" && (
          <>
            <h2>تسجيل الدخول</h2>
            <div style={card}>
              <label>الاسم أو البريد الإلكتروني</label>
              <input
                value={user}
                onChange={e => setUser(e.target.value)}
                placeholder="أدخل اسمك"
                style={field}
              />

              <label>كلمة المرور</label>
              <input
                type="password"
                placeholder="كلمة المرور"
                style={field}
              />

              <button
                style={{ ...button, width: "100%" }}
                onClick={() => {
                  if (!user.trim()) {
                    notify("أدخل اسمك أولاً");
                    return;
                  }
                  setLogged(true);
                  setPage("profile");
                  notify("تم الدخول في هذه المعاينة");
                }}
              >
                دخول
              </button>

              <p>
                ليس لديك حساب؟
                <button
                  onClick={() => setPage("register")}
                  style={{
                    border: 0,
                    color: "#087c50",
                    background: "transparent"
                  }}
                >
                  إنشاء حساب
                </button>
              </p>
            </div>
          </>
        )}

        {page === "register" && (
          <>
            <h2>إنشاء حساب جديد</h2>
            <div style={card}>
              <p>اختر نوع الحساب:</p>

              <div style={{ display: "flex", gap: 10 }}>
                <button
                  onClick={() => setRole("worker")}
                  style={{
                    ...button,
                    flex: 1,
                    background: role === "worker" ? "#087c50" : "#aabbb1"
                  }}
                >
                  عامل
                </button>

                <button
                  onClick={() => setRole("employer")}
                  style={{
                    ...button,
                    flex: 1,
                    background: role === "employer" ? "#087c50" : "#aabbb1"
                  }}
                >
                  صاحب عمل
                </button>
              </div>

              <input
                value={user}
                onChange={e => setUser(e.target.value)}
                placeholder="الاسم الكامل"
                style={field}
              />

              <input
                placeholder="رقم الهاتف"
                type="tel"
                style={field}
              />

              <input
                placeholder="البريد الإلكتروني"
                type="email"
                style={field}
              />

              <input
                placeholder="كلمة المرور"
                type="password"
                style={field}
              />

              <button
                style={{ ...button, width: "100%" }}
                onClick={() => {
                  if (!user.trim()) {
                    notify("أدخل اسمك أولاً");
                    return;
                  }
                  setLogged(true);
                  setPage("profile");
                  notify("تم إنشاء حساب تجريبي");
                }}
              >
                إنشاء الحساب
              </button>
            </div>
          </>
        )}

        {page === "profile" && (
          <>
            <h2>حسابي</h2>
            <div style={card}>
              <h3>مرحباً {user || "بك"} 👋</h3>
              <p>
                نوع الحساب: {role === "worker" ? "عامل" : "صاحب عمل"}
              </p>
              <p>الطلبات المرسلة: {applications.length}</p>
              <p>الوظائف المفضلة: {favorites.length}</p>

              <button
                style={{ ...button, background: "#b42318" }}
                onClick={() => {
                  setLogged(false);
                  setPage("home");
                  notify("تم تسجيل الخروج");
                }}
              >
                تسجيل الخروج
              </button>
            </div>
          </>
        )}

        {selectedJob && (
          <div style={{
            position: "fixed",
            inset: 0,
            background: "#0008",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 20,
            zIndex: 20
          }}>
            <div style={{
              ...card,
              width: "100%",
              maxWidth: 420
            }}>
              <button
                onClick={() => setSelectedJob(null)}
                style={{
                  ...button,
                  float: "left",
                  background: "#64748b"
                }}
              >
                إغلاق ✕
              </button>

              <h2>{selectedJob.title}</h2>
              <p>📍 {selectedJob.location}</p>
              <p>💰 {selectedJob.salary}</p>
              <p>{selectedJob.description}</p>

              <button
                style={button}
                onClick={() => {
                  apply(selectedJob.id);
                  setSelectedJob(null);
                }}
              >
                التقديم للعمل
              </button>
            </div>
          </div>
        )}
      </div>

      <nav style={{
        position: "fixed",
        bottom: 0,
        left: 0,
        right: 0,
        background: "white",
        borderTop: "1px solid #ddd",
        display: "flex",
        justifyContent: "space-around",
        padding: "12px 4px",
        zIndex: 10
      }}>
        {[
          ["home", "🏠", "الرئيسية"],
          ["jobs", "🔎", "الوظائف"],
          ["post", "➕", "نشر عمل"],
          ["favorites", "❤️", "المفضلة"],
          ["profile", "👤", "حسابي"]
        ].map(([id, icon, label]) => (
          <button
            key={id}
            onClick={() => setPage(id)}
            style={{
              border: 0,
              background: "transparent",
              color: page === id ? "#087c50" : "#64748b",
              fontSize: 11,
              fontWeight: "bold"
            }}
          >
            <div style={{ fontSize: 20 }}>{icon}</div>
            {label}
          </button>
        ))}
      </nav>
    </main>
  );
}