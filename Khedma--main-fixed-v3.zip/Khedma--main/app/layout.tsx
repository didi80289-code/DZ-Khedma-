import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Khedma DZ",
  description: "منصة العمل اليومي والمؤقت في الجزائر"
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl">
      <body style={{ margin: 0 }}>
        {children}
      </body>
    </html>
  );
}